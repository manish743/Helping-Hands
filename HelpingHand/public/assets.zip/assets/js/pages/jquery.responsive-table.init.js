/**
 * Theme: Dastone - Responsive Bootstrap 5 Admin Dashboard
 * Author: Mannatthemes
 * Responsive-table Js
 */

 
$(function() {
  $('.table-responsive').responsiveTable({
      addDisplayAllBtn: 'btn btn-secondary'
  });
});